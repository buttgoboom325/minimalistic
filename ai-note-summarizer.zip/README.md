# AI Note Summarizer
A ChromeOS-compatible AI summarizer and flashcard generator.
